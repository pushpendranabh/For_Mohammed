package apitesting;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import apitesting.utils.TestTO;

public class ThirdpartyAPITest {

	int number = 0;
	ObjectMapper mapper;
	HttpUriRequest request;
	HttpResponse response;

	@BeforeClass
	public void init() throws ClientProtocolException, IOException {
		mapper = new ObjectMapper();
		request = new HttpGet("https://api.ipify.org?format=json");
		response = HttpClientBuilder.create().build().execute(request);
	}

	@Test
	public void test_request_status() throws ClientProtocolException, IOException {

		Assert.assertEquals(response.getStatusLine().getStatusCode(), HttpStatus.SC_OK);
	}

	@Test
	@Parameters({ "expectedCorrectIP" ,"expectedFakeIP"})
	public void test_CorrectIp(String expectedCorrectIP,String expectedFakeIP) throws ClientProtocolException, IOException {

		TestTO acutalIP = mapper.readValue(response.getEntity().getContent(), TestTO.class);
		
		Assert.assertEquals(acutalIP.getIp(), expectedCorrectIP);
		Assert.assertNotEquals(acutalIP.getIp(), expectedFakeIP);
		

	}
	
}
